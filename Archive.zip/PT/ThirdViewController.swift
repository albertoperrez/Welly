//
//  ThirdViewController.swift
//  PT
//
//  Created by Roberto  Viramontes on 3/1/19.
//  Copyright © 2019 Roberto  Viramontes. All rights reserved.
//

import UIKit

class ThirdViewControlle: UICollectionViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.backgroundColor = .white
    }
}
