//
//  SecondViewController.swift
//  PT
//
//  Created by Roberto  Viramontes on 3/1/19.
//  Copyright © 2019 Roberto  Viramontes. All rights reserved.
//

import UIKit
import WatchConnectivity
import Charts

class SecondViewController: UICollectionViewController, WCSessionDelegate {

    var barView2 = ScatterChartView()
    var charEntry1 = [ChartDataEntry]()
    var charEntry2 = [ChartDataEntry]()
    var charEntry3 = [ChartDataEntry]()
    var gravityArray = [Double]()
    var accelerationArray = [Double]()
    
    var session: WCSession!

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.backgroundColor = .white
        
        view.addSubview(barView2)
        barView2.anchor(top: nil, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, paddingTop: 0, paddingLeft: 10, paddingBottom: 0, paddingRight: 10, width: 0, height: 500)
        barView2.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
        if (WCSession.isSupported()) {
            session = WCSession.default
            session.delegate = self
            session.activate()
        }
        
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) {
        //handle received message
        print("Here is the data from the apple watch: ", message)
        guard let gravX = message["gX"] as? Double else { return }
        guard let gravY = message["gY"] as? Double else { return }
        guard let gravZ = message["gZ"] as? Double else { return }
        
        guard let acceX = message["aX"] as? Double else { return }
        guard let acceY = message["aY"] as? Double else { return }
        guard let acceZ = message["aZ"] as? Double else { return }
        
        let value1 = ChartDataEntry(x: gravX, y: gravY)
        let value2 = ChartDataEntry(x: acceX, y: acceY)
        let value3 = ChartDataEntry(x: gravZ, y: acceZ)
        
        charEntry1.append(value1)
        charEntry2.append(value2)
        charEntry3.append(value3)
        
        let scat1 = ScatterChartDataSet(values: charEntry1)
        scat1.setScatterShape(.circle)
        let scat2 = ScatterChartDataSet(values: charEntry2)
        scat2.setScatterShape(.square)
        let scat3 = ScatterChartDataSet(values: charEntry3)
        scat3.setScatterShape(.triangle)
        
        let data = ScatterChartData()
        data.addDataSet(scat1)
        data.addDataSet(scat2)
        data.addDataSet(scat3)
        barView2.data = data
        
        //use this to present immediately on the screen
        DispatchQueue.main.async {
            
        }
        //send a reply
        replyHandler(["Value":"Yes"])
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("Session Active: \(activationState), Error: \(error?.localizedDescription ?? "")")
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        print("Phone session inactive")

    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        print("Phone session deactive")

    }
}
