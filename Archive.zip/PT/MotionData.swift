//
//  MotionData.swift
//  PT
//
//  Created by Roberto  Viramontes on 3/2/19.
//  Copyright © 2019 Roberto  Viramontes. All rights reserved.
//

import Foundation

struct Motion {
    var gravity: String
    var value: Double
}

class DataGenerator {

    static func data() -> [Motion] {
        let gravities = ["X", "Y", "Z"]
        var sales = [Motion]()
        
        for grav in gravities {
            let sale = Motion(gravity: grav, value: 0)
            sales.append(sale)
        }
        
        return sales
    }
}
