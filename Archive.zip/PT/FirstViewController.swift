//
//  FirstViewController.swift
//  PT
//
//  Created by Roberto  Viramontes on 3/1/19.
//  Copyright © 2019 Roberto  Viramontes. All rights reserved.
//

import UIKit
import CoreMotion
import CoreGraphics
import os.log
import Charts

class FirstViewController: UICollectionViewController {
    
    let motionManager = CMMotionManager()
    var barView =  LineChartView()
    var barView2 = ScatterChartView()
    var lineChartEntry = [ChartDataEntry]()
    var lineChartEntry2 = [ChartDataEntry]()
    var lineChartEntry3 = [ChartDataEntry]()
    var lineChartEntry4 = [ChartDataEntry]()


    
    var gravity = [Double]()
    var acceleration = [Double]()
    var attitude = [Double]()
    var rotation = [Double]()
    var motionDevice: CMDeviceMotion?
    
    let testView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
        return view
    }()

    
    let startExerciseButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 32)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor.rgb(red: 348, green: 82, blue: 100)
        button.layer.cornerRadius = 75
        button.clipsToBounds = true
        button.addTarget(self, action: #selector(handleStart), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.backgroundColor = .white
        tabBarController?.tabBar.isTranslucent = false
        motionManager.deviceMotionUpdateInterval = 1.0 / 50
        
        view.addSubview(barView2)
        view.addSubview(startExerciseButton)
        barView2.anchor(top: view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, paddingTop: 20, paddingLeft: 10, paddingBottom: 0, paddingRight: 10, width: 0, height: 450)
        startExerciseButton.anchor(top: nil, left: nil, bottom: view.safeAreaLayoutGuide.bottomAnchor, right: nil, paddingTop: 0, paddingLeft: 20, paddingBottom: 30, paddingRight: 20, width: 150, height: 150)
        startExerciseButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
    }
    
    func processDeviceMotion(deviceMotion: CMDeviceMotion) {
        
        gravity = [deviceMotion.gravity.x,
                  deviceMotion.gravity.y,
                  deviceMotion.gravity.z]
        print("Gravity: X: \(gravity[0]), Y: \(gravity[1]), Z: \(gravity[2])")
        
        acceleration = [deviceMotion.userAcceleration.x,
                        deviceMotion.userAcceleration.y,
                        deviceMotion.userAcceleration.z]
        print("Acceleration: X: \(acceleration[0]), Y: \(acceleration[1]), Z: \(acceleration[2])")
        
        rotation = [deviceMotion.rotationRate.x,
                    deviceMotion.rotationRate.y,
                    deviceMotion.rotationRate.z]
        print("Rotation: X: \(rotation[0]), Y: \(rotation[1]), Z: \(rotation[2])")

        
        attitude = [deviceMotion.attitude.roll,
                    deviceMotion.attitude.pitch,
                    deviceMotion.attitude.yaw]
        print("Attitude: X: \(attitude[0]), Y: \(attitude[1]), Z: \(attitude[2])")
        
        let value = ChartDataEntry(x: deviceMotion.userAcceleration.x, y: deviceMotion.userAcceleration.y)
        lineChartEntry.append(value)
        
        let value2 = ChartDataEntry(x: deviceMotion.gravity.x, y: deviceMotion.gravity.y)
        lineChartEntry2.append(value2)
        
        let value3 = ChartDataEntry(x: deviceMotion.attitude.roll, y: deviceMotion.attitude.pitch)
        lineChartEntry3.append(value3)
        
        let value4 = ChartDataEntry(x: deviceMotion.gravity.z, y: deviceMotion.userAcceleration.z)
        lineChartEntry4.append(value4)
        
        let timeStamp = Date().millisecondsSince1970
        os_log("Motion: %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@",
               String(timeStamp),
               String(deviceMotion.gravity.x),
               String(deviceMotion.gravity.y),
               String(deviceMotion.gravity.z),
               String(deviceMotion.userAcceleration.x),
               String(deviceMotion.userAcceleration.y),
               String(deviceMotion.userAcceleration.z),
               String(deviceMotion.rotationRate.x),
               String(deviceMotion.rotationRate.y),
               String(deviceMotion.rotationRate.z),
               String(deviceMotion.attitude.roll),
               String(deviceMotion.attitude.pitch),
               String(deviceMotion.attitude.yaw))
        
    }
    
    @objc func handleStart() {
        self.barView2.clear()
        motionManager.startDeviceMotionUpdates(to: .main) { (deviceMotion, err) in
            if let err = err {
                print("Failed to update motion: ", err.localizedDescription)
            }
            guard let data = deviceMotion else { return }
            self.processDeviceMotion(deviceMotion: data)
            
//            if data.userAcceleration.x < -1.5 {
//                self.collectionView.backgroundColor = UIColor.red
//            } else if data.userAcceleration.x > 1.5 {
//                self.collectionView.backgroundColor = UIColor.green
//            } else if data.attitude.pitch < -0.5 {
//                self.collectionView.backgroundColor = UIColor.purple
//            } else if data.attitude.pitch > 0.5 {
//                self.collectionView.backgroundColor = UIColor.blue
//            }
            
            if self.startExerciseButton.currentTitle == "Start" {
                self.startExerciseButton.setTitle("Stop", for: .normal)
                self.startExerciseButton.addTarget(self, action: #selector(self.handleStop), for: .touchUpInside)
                
            }
        }
        
    }
    
    @objc func handleStop() {
        motionManager.stopDeviceMotionUpdates()
        let line1 = LineChartDataSet(values: lineChartEntry, label: "Acceleration")
        line1.colors = [UIColor.blue]
        line1.circleColors = [UIColor.blue]
        
        let line2 = LineChartDataSet(values: lineChartEntry2, label: "Gravity")
        line2.circleColors = [UIColor.red]
        line2.colors = [UIColor.red]
        
        let line3 = LineChartDataSet(values: lineChartEntry3, label: "Attitude")
        line3.circleColors = [UIColor.green]
        line3.colors = [UIColor.green]
        
        let scat1 = ScatterChartDataSet(values: lineChartEntry)
        scat1.setScatterShape(.circle)
        let scat2 = ScatterChartDataSet(values: lineChartEntry2)
        scat2.setScatterShape(.square)
        let scat3 = ScatterChartDataSet(values: lineChartEntry3)
        scat3.setScatterShape(.triangle)
        let scat4 = ScatterChartDataSet(values: lineChartEntry4)
        scat4.setScatterShape(.cross)
        
        

        
        let data = ScatterChartData()
        //data.addDataSet(scat1)
        data.addDataSet(scat2)
        data.addDataSet(scat3)
        //data.addDataSet(scat4)
        barView2.data = data
        barView2.chartDescription?.text = "Here is some motion"
        
        if self.startExerciseButton.currentTitle == "Stop" {
            self.startExerciseButton.setTitle("Start", for: .normal)
            self.startExerciseButton.addTarget(self, action: #selector(self.handleStart), for: .touchUpInside)
        }
    }
    
}
