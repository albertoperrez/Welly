//
//  MainTabController.swift
//  PT
//
//  Created by Roberto  Viramontes on 3/1/19.
//  Copyright © 2019 Roberto  Viramontes. All rights reserved.
//

import UIKit

class MainTabController: UITabBarController, UITabBarControllerDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViewController()
        
    }
    
    func setupViewController () {
        let firstViewController = templateTabController(unselectedImage: #imageLiteral(resourceName: "HomeOff"), selectedImage: #imageLiteral(resourceName: "home"), rootiViewController: SecondViewController(collectionViewLayout: UICollectionViewFlowLayout()))
        let seconViewController = templateTabController(unselectedImage: #imageLiteral(resourceName: "playOff"), selectedImage: #imageLiteral(resourceName: "play"), rootiViewController: FirstViewController(collectionViewLayout: UICollectionViewFlowLayout()))
        let thirdViewController = templateTabController(unselectedImage: #imageLiteral(resourceName: "profile off"), selectedImage: #imageLiteral(resourceName: "profile"), rootiViewController: ThirdViewControlle(collectionViewLayout: UICollectionViewFlowLayout()))
        
        viewControllers = [firstViewController,seconViewController,thirdViewController]
        
        //Modify tab bar item insets
        guard let items = tabBar.items else { return }
        //We modify the edges of the items on the tabBar
        for item in items {
            item.imageInsets = UIEdgeInsets(top: 4, left: 0, bottom: -4, right: 0)
            
        }
    }
    
    func templateTabController(unselectedImage: UIImage, selectedImage: UIImage, rootiViewController: UIViewController = UIViewController()) -> UINavigationController {
        let viewController = rootiViewController
        let navController = UINavigationController(rootViewController: viewController)
        navController.tabBarItem.image = unselectedImage
        navController.tabBarItem.selectedImage = selectedImage
        return navController
    }
}
